import java.util.Scanner;
public class ascii {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("enter the String:");
String str1=sc.nextLine();
char str2=str1.charAt(2);
System.out.println((int)str2);



	}

}
