import java.util.Arrays;
public class fibonacii1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int a[]=new int[8];
     int f1=-1,f2=1;
     for(int i=0;i<a.length;i++)
     {
    	 int c=f1+f2;
    	 System.out.println(c);
    	 f1=f2;
    	 f2=c;
     }
	}

}
