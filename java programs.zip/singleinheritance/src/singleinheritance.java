import java.io.*;
import java.util.Scanner;
class student
{
	int r_no;
	String name;
	void getdata(int r_no,String name)
	{
		this.r_no=r_no;
		this.name=name;
	}
	void display()
	{
		System.out.println("\n\t\tSINGLE INHERITANCE");
		System.out.println("roll no:"+r_no);
		System.out.println("name:"+name);
	}
	
}
class marks extends student
{
	float m1,m2,m3,m4,m5;
	marks(float m1,float m2,float m3,float m4,float m5)
	{
		this.m1=m1;
		this.m2=m2;
		this.m3=m3;
		this.m4=m4;
		this.m5=m5;
	}
	void display_marks()
	{
		System.out.println("Mark1:"+m1);
		System.out.println("Mark2:"+m2);
		System.out.println("Mark3:"+m3);
		System.out.println("Mark4:"+m4);
		System.out.println("Mark5:"+m5);
		float avg;
		avg=(m1+m2+m3+m4+m5)/5;
		System.out.println("Average:"+avg);
		
	}
}
public class singleinheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the roll no:");
	 int r_no=sc.nextInt();
	System.out.println("Enter the name:");
	 String name=sc.next();
	 System.out.println("enter the mark1:");
	 float m1=sc.nextFloat();
	 System.out.println("enter the mark2:");
	 float m2=sc.nextFloat();
	 System.out.println("enter the mark3:");
	 float m3=sc.nextFloat();
	 System.out.println("enter the mark4:");
	 float m4=sc.nextFloat();
	 System.out.println("enter the mark5:");
	 float m5=sc.nextFloat();
	 marks m=new marks(m1,m2,m3,m4,m5);
     m.getdata(r_no, name);
     m.display();
     m.display_marks();
    
	}

}
