public class additionadd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int a[][]= {{1,2,3,4},
		     {5,6,7,8},    
		     {2,3,4,5}};
 int b[][]= {{1,2,3,4},
		     {6,7,8,9},
		     {4,5,6,7}};
 int row=a.length;
 int cols=a[0].length;
 int c[][]=new int[row][cols];
 for(int i=0;i<row;i++)
 {
	 for(int j=0;j<cols;j++)
	 {
	 c[i][j]=a[i][j]+b[i][j];
		System.out.print(c[i][j]+"  ");
	 }
	 System.out.println("  ");
 }
 
	}

}
