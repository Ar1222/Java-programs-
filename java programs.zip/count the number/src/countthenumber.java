import java.util.Scanner;
public class countthenumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner sc=new Scanner(System.in);
  System.out.println("enter the number:");
	int n1=sc.nextInt();
	int count=0;
	while(n1!=0)
	{
		n1=n1/10;
		count++;
	}
	System.out.println(count);
	}

}
