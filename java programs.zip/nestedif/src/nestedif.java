import java.util.Scanner;
public class nestedif {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the marital status M/U:");
		char marital=sc.next().charAt(0);
		if(marital=='M'||marital=='m' )
		{
			System.out.println("you are eligible for insurance");
		}
		else if(marital=='U'||marital=='u')
		{
			System.out.println("enter the gender M/F:");
			char gender=sc.next().charAt(0);
			System.out.println("enter the age:");
			int age=sc.next().charAt(0);
			if(gender=='M'&& age>=30)
			{
				System.out.println("you are eligible for insurance");
			}
			else if(gender=='F'&&age>=20)
			{
				System.out.println("you are eligible for insurance");
			}
			else
			{
				System.out.println("you are not eigible for insurance");
				
			}
			
		}
		else
		{
			System.out.println("Invalid choice");
		
		}

	}

}
