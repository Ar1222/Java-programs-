import java.util.Scanner;
public class maximum {
	public static int maximum(int n1,int n2)
	{
		int max;
		if(n1>n2)
		{
			max=n1;
		}
		else
		{
			max=n2;
		}
		return max;
	}
	public static double maximum(double n1,double n2)
	{
		double max;
		if(n1>n2)
		{
			max=n1;
		}
		else
		{
			max=n2;
		}
		return max;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.println("\n\t\t METHODOVERLOADING");
    Scanner sc=new Scanner(System.in);
    System.out.println("enter the integer value for a:");
    int a=sc.nextInt();
    System.out.println("enter the integer value for b:");
    int b=sc.nextInt();
    int result1=maximum(a,b);
    System.out.println("Maximum number of integer:"+result1);
    System.out.println("enter the double value for c:");
    double c=sc.nextDouble();
    System.out.println("enter the double value for d:");
    double d=sc.nextDouble();
    double result2=maximum(c,d);
    System.out.println("Maximum number of double:"+result2);
    
    
    
	}

}
