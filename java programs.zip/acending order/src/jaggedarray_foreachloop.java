
public class jaggedarray_foreachloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[][]= {{10,20,30,40,50},
			    {40,50,60},
			    {70,80,90,40}};
		for(int[]i:a)
		{
			for(int j:i)
			{
				System.out.print(" "+j);
			}
			System.out.println(" ");
		}
	}

}
