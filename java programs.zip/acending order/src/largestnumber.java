import java.util.Arrays;
public class largestnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int a[]= {10,2,3,4,15};
  int max=a[0];
  int min=a[0];
  for(int i=0;i<a.length;i++)
  {
		  if(a[i]<min)
		  {
			  
			  min=a[i];
		  }
		  if(a[i]>max)
		  {
			  max=a[i];
		  }
	  
  }
  System.out.println("largest number is:"+max);
  System.out.println("smallest number is:"+min);


 
	}

}
