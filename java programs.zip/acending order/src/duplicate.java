import java.util.Arrays;
public class duplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int a[]= {1,2,3,2,4,5,4,6,6};
       for(int i=0;i<=a.length-1;i++)
       {
    	   for(int j=i+1;j<=a.length-1;j++)
    	   {
    		   if(a[i]==a[j]&&(i!=j))
    		   {
    			   System.out.println(" duplicate element:"+a[j]);
    		   }
    	   }
       }
	}

}
