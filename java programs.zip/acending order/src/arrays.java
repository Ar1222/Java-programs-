import java.util.Arrays;

public class arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int a[]= {3,4,6,7,2,1,5};
    System.out.println("before sorting:"+Arrays.toString(a));
    int temp;
    for(int i=0;i<a.length;i++)
    {
    	for(int j=i+1;j<a.length;j++) 
    	{
    		if(a[i]>a[j])
    		{
    			temp=a[i];
    			a[i]=a[j];
    			a[j]=temp;
    		}
    		
    		
    	}
    	
    }
    System.out.println("after sorting:"+Arrays.toString(a));
    
	}

}
