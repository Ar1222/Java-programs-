import java.util.Arrays;
public class deletearray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int a[]= {1,2,3,4,5};
   int value=3;
   for(int i=0;i<a.length;i++)
   {
	   if(a[i]==value)
	   {
		   for(int j=i;j<a.length-1;j++)
		   {
	        a[j]=a[j+1];
		   }
	   }
   }
   for(int i=0;i<a.length-1;i++) {
      
   System.out.print(a[i]);
   }
	}

	

	
	}


