
public class fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int a[]=new int[10];
  int n1=-1,n2=1;
  for(int i=0;i<a.length;i++) {
	  int n3=n1+n2;
	  System.out.println(n3);
	  n1=n2;
	  n2=n3;
  }
	}

}
