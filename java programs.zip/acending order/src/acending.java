import java.util.Arrays;
public class acending {
	public static void main(String arg[]) {
		 int a[]= {3,4,2,6,1,7,5};
	       System.out.println("before sorting"+Arrays.toString(a));
	       int temp=0;
	       for(int i=0;i<a.length;i++)
	       {
	    	   for(int j=i+1;j<a.length;j++)
	    	   {
	    		   if(a[i]>a[j])
	    		   {
	    		   temp=a[i];
	    		   a[i]=a[j];
	    		   a[j]=temp;
	    		   }
	    	   }
	       }
	       System.out.println("after sorting"+Arrays.toString(a));
	}
      
       
}
