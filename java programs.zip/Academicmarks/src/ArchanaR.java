import java.io.*;
interface semA
{
	String name="Archana",Department="Computer Science";
	int roll_no=101;
	float tamil=70,english=98,c_lang=80,maths=92,dcf=86,Evs=89,semA_percentage=79;
	void display();
}
interface semB
{
	String name="Archana",Department="Computer Science";
	int roll_no=101;
	float tamil=90,english=98,c_lang=90,maths=92,CSA=88,VE=90,semB_percentage=86;
	void display();
}
class semester implements semA,semB
{
	 String b,c,e,f;
	 int d,g;
	 double a,h;
	 public void display()
	{
    b=semA.name;
   	c=semA.Department;
    d=semA.roll_no;
    System.out.println("\t\t FIRST SEMESTER ");
    System.out.println("Student Name:"+b);
    System.out.println("Student Department:"+c);
    System.out.println("Student roll number:"+d);
	}
	 public void display_semB()
	 {
		    e=semB.name;
		   	f=semB.Department;
		    g=semB.roll_no;
		    System.out.println("\t\tSECOND SEMESTER");
		    System.out.println("Student Name:"+b);
		    System.out.println("Student Department:"+c);
		    System.out.println("Student roll number:"+d);
		    System.out.println("\t\tTOTAL PERCENTAGE");
		    double total=(semA.semA_percentage+semB.semB_percentage)/2;
		    System.out.println("the student total performance:"+total);
		 
	 }
	
}
public class ArchanaR {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\t\tACEDEMIC YEAR STUDY PERFORMANCE");
      semester s=new semester();
      s.display();
      s.display_semB();
      
	}

}
