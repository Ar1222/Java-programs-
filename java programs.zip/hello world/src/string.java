import java.util.Scanner;
public class string {
	public static void main(String arg[])
	{
	String str1,str2,str3;
	Scanner sc=new Scanner(System.in);
	System.out.println("equalvality of two strings");
	
	System.out.println("enter teh string 1:");
	str1=sc.nextLine();
	System.out.println("enter teh string 2:");
	str2=sc.nextLine();
	if(str1.equals(str2))
	{
		System.out.println("strings are equal");
	}
	else {
		System.out.println("strings are not equal");
	}
	System.out.println("REVERSE THE STRING");
	System.out.println("enter the third string:");
	str3=sc.nextLine();
	System.out.println("reverse the string is:");
	char a[]=str3.toCharArray();
	for(int i=a.length-1;i>=0;i--)
	{
	 System.out.println(a[i]);
	}
	
	}
}
