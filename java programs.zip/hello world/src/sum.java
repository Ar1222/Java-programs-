import java.util.Scanner;
public class sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int num,sum=0,digit;
       Scanner sc=new Scanner(System.in);
       System.out.print("Enter the number:");
       num=sc.nextInt();
       while(num>0)
       {
    	  digit=num%10;
    	  sum=sum+digit;
    	  num=num/10;
       }
       System.out.println("sum of digits is"+sum);
	}

}
