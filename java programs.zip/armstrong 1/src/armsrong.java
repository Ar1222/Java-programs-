
public class armsrong {
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n1,n2,n3;
for(int n=100;n<=999;n++)
{
	int temp=n;
	n3=temp%10;
	temp=temp/10;
	n2=temp%10;
	temp=temp/10;
	n1=temp%10;
	int result=(n1*n1*n1)+(n2*n2*n2)+(n3*n3*n3);
  if(result==n) {
	System.out.println( result+ "armstrong number");
  }
}
	}

}
