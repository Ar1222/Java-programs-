import java.util.Arrays;
public class insert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub                                                                              
   int a[]= {10,20,40,50,60};
   int index=2;
   int value=30;
   for(int i=a.length-1;i>index;i--)
   {
	  a[i]=a[i-1];
   }
   a[index]=value;
   System.out.println("after insert:"+Arrays.toString(a));
	}

}
