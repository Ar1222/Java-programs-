import java.util.Scanner;
public class string {

	public static void main(String[] args) {
		
		/*String s="hello world";
		System.out.println(s.charAt(9));
		System.out.println(s.contains("hellos"));
		System.out.println(s.substring(5));
		System.out.println(s.substring(5,9));*/
		/*String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string:");
		str=sc.nextLine();
		char a[]=str.toCharArray();
		for(int i=a.length-1;i>0;i--)
		{
			System.out.println(a[i]);
		}*/
		
		StringBuilder s=new StringBuilder("i love java");
		s.append( " as a developer");
		s.insert(11," and coding");
		s.replace(2, 6," like");
		s.delete(8, 16);
		System.out.println(s);


		

	}

}
