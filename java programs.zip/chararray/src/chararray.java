
public class chararray {
	public static String change_char(String s){
		if(s.isEmpty())
		{
			return s;
		}
		char a=s.charAt(0);
		StringBuilder sb=new StringBuilder(s.length());
		sb.append(a);
		for(int i=1;i<s.length();i++)
		{
			char present=s.charAt(i);
					if(present==a)
					{
						sb.append('$');
					}
					else
					{
						sb.append(present);
					}
		}
		return sb.toString();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String str="Archana";
		char[] a= {'a','r','c','h','a','n','a'};
		System.out.println(str);
		System.out.println(a);
		char ar[]=str.toCharArray();
		 String s=new String(a);  
		 
		 System.out.println(ar);
			System.out.println(s);*/
		 String str="archana";
		 System.out.println(str);
 
	}
} 

