import java.util.*;
public class upper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner sc=new Scanner(System.in);
		  System.out.println("enter the string:");
		  String s=sc.nextLine();
		  
		  System.out.println(s.toLowerCase());
		  System.out.println(s.toUpperCase());
		  
	}

}
