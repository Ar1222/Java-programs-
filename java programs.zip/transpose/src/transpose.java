import java.util.Scanner;
public class transpose {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int m[][]= {{10,20,30},
		 {20,30,40},
		 {60,80,90}};
 
 for(int i=0;i<m.length;i++)
 {
	 for(int j=0;j<m.length;j++)
	 {
		 System.out.print(m[j][i]+" ");
	 }
	 System.out.println(" ");
 }
	}

}
