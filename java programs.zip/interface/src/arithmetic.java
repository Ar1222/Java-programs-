import java.io.*;
interface A
{
	int a=10;
	int b=30;
	void show();
}
interface B
{
	int a=19;
	int b=39;
	void show();
}
class C
{
	int c,d,e,f;
	void show()
	{
	c=A.a+A.b;
	d=A.a-A.b;
	e=A.b*B.b;
	f=A.a/B.a;
	}
	void s()
	{
		System.out.println("Arithmetic:"+c);
		System.out.println("Subtraction:"+d);
		System.out.println("Multiplication:"+e);
		System.out.println("Division:"+f);
	}
}
public class arithmetic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     C obj=new C();
     obj.show();
     obj.s();
	}

}
