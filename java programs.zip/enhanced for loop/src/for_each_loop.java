import java.util.Scanner;
public class for_each_loop {
	public static void main(String arg[])
	{
		/*int a[]= {2,3,5,7,11,13,17};
		for(int i:a)
		{
			System.out.println("."+i);
		}
		*/
		
		for(int i=5;i!=0;i--)
		{
			for(int j=5;j<=i;j--)
			{
				System.out.print("*");
			}
			System.out.println(" ");
		}
	}

}
