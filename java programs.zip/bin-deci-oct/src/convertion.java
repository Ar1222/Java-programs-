import java.util.Scanner;
public class convertion {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String binary,octal;
		System.out.println("ener the binary number:");
		binary=sc.nextLine();
		int dec;
		dec=Integer.parseInt(binary,2);
		System.out.println("decimal:"+dec);
		octal=Integer.toOctalString(dec);
		System.out.println("octal:"+octal);
		
	}

}
