import java.io.*;
import java.util.Scanner;
class employee
{
	String name;
	int empid;
	long mobile;
	Scanner sc=new Scanner(System.in);
	void getdata()
	{
		System.out.println("\t\t INHERITANCE");
		
		System.out.println("Enter the name of the employee:");
		name=sc.nextLine();
		System.out.println("Enter the empolyee id:");
		empid=sc.nextInt();
		System.out.println("enter the mobile number of he employee:");
		mobile=sc.nextLong();
	}
	void display()
	{
		System.out.println("Name:"+name);
		System.out.println("employee id:"+empid);
		System.out.println("mobileNumber:"+mobile);
	}
}
class salary1 extends employee
{
	double da, bp,pf,hra,club,net,gross;
	void read()
	{
	System.out.println("Enter the basic pay:");
	bp=sc.nextDouble();
	}
	
	void calculate()
	{
		da=0.97*bp;
		hra=0.12*bp;
		pf=0.10*bp;
		club=0.01*bp;
		gross=da+hra+bp;
		net=gross-pf+club;
	}
	void display()
	{
		System.out.println("\t\t\tPAY SLIP");
		System.out.println("BP="+bp+"\t\t\t\tda="+da);
		System.out.println("HRA="+hra+"\t\t\t\tpf="+pf);
		System.out.println("CLUB="+club+"\t\t\t\tNET="+net);
		System.out.println("GROSS="+gross);
		
		
	}
}
public class salary {
	public static void main(String arg[])
	{
	salary1 s=new salary1();
	s.getdata();
	s.read();
	s.calculate();
	s.display();
	}
	

}
