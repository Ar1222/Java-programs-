
public class multiplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int i, n=5,m=20;
     System.out.println("Multiplication table of 5");
     for(i=1;i<=m;i++)
     {
    	if(n*i>30)
    	{
    		System.out.println("exit the loop");
    		break;
    	}
    	System.out.println(i+"*"+n+"="+i*n);
     }
	}

}
