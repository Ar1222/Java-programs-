//tranpose the matric rows to coloumn
public class func {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int [][]a= {{1,2,3,4},{5,6,7,8},{1,3,2,4},{1,5,6,7}};
     int rows=a.length;
     int cols=a[0].length;
     for( int j=0;j<cols;j++)
     {
    	 for( int i=0;i<rows;i++) {
    		 System.out.print(a[i][j] + "");
    		 
    	 }
         System.out.println();
    	
     }
     

	}

}
