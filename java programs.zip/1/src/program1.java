import java .util.Scanner;
public class program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String str1,str2,str3;
     System.out.println("\t\t equality of a string:");
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter the first string:");
     str1=sc.nextLine();
     System.out.println("Enter the second string:");
     str2=sc.nextLine();
     if (str1.equals(str2)) {
    	 System.out.println("strings are eqaul");
     }
     
    	 else
    	 {
    		 System.out.println("strings are not equal");
    		 
     }
     System.out.println("reverse the string");
     System.out.println("enter the third string:");
     str3=sc.nextLine();
     char a[]=str3.toCharArray();
     for(int i=a.length-1;i>=0;i--)
     {
    	 System.out.println(a[i]);
    	 
     }
     
     
	}

}
