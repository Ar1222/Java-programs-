import java.util.Scanner;
public class power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the no of x:");
		double x=sc.nextDouble();
		System.out.println("enter the no of y:");
		double y=sc.nextDouble();
		System.out.println(Math.pow(y, x));
		
	}

}
