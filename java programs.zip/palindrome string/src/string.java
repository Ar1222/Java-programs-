import java.util.Scanner;
public class string {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string:");
		String str=sc.nextLine();
 StringBuilder sb=new StringBuilder(str);
  sb.reverse();
  String rev=sb.toString();
  if(str.equals(rev))
  {
	  System.out.println(str+" is a plaindrome");
  }
  else
  {
	  System.out.println(str+" is not a palindrome");
  }
	}

}
