import java.util.Scanner;
public class linear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int []a= {10,20,30,40,90};
       Scanner sc=new Scanner(System.in);
       System.out.println("enter the key:");
       int key=sc.nextInt();
       int flag=0;
       for( int i=0;i<a.length;i++)
       {
    	  if(a[i]==key)
    	  {
    		  System.out.println("found at"+i);
    		  flag=1;
    		  break;
    	  }
    }
       if(flag==0)
    	   System.out.println("element not found");
 	  
	}

}
