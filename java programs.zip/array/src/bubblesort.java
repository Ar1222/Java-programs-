import java.util.Arrays;

public class bubblesort {
	public static void main(String arg[])
	{
		int a[]= {10,3,4,2,5,8,7,6,9};
		System.out.println(Arrays.toString(a));
		for(int i=0;i<a.length-1;i++)
		{
			for(int j=0;j<a.length-1-i;j++)
			{
				if(a[j]>a[j+1])
				{
				  int t=a[j];
				  a[j]=a[j+1];
				  a[j+1]=t;
				}
			}
		}
		System.out.println(Arrays.toString(a));
	}

}
