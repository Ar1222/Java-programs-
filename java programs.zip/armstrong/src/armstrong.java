import java.util.Scanner;
public class armstrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner sc=new Scanner(System.in);
  System.out.println("enter the number:");
  int n=sc.nextInt();
  int n1,n2,n3;
  int temp=n;
  n3=temp%10;
  temp=temp/10;
  n2=temp%10;
  temp=temp/10;
  n1=temp%10;
  
  int result=(n1*n1*n1)+(n2*n2*n2)+(n3*n3*n3);
  if(result==n)
  {
	  System.out.println("armstrong number");
  }
  else
  {
	  System.out.println("not an armstrong number");
  }
	}

}
