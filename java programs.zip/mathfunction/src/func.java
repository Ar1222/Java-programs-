import java.util.Scanner;
class mathfunc
{
	long a,b;
	double c;
	mathfunc(long a,long b,double c)
	{
		this.a=a;
		this.b=b;
		this.c=c;
	}
	void basicmathfunction()
	{
		System.out.println("\n\n\t BASIC MATH FUNCTION");
		System.out.println("Maximum:"+Math.max(a, b));
		System.out.println("Minimum:"+Math.min(a,b));
		System.out.println("power:"+Math.pow(a, b));
		System.out.println("square root:"+Math.sqrt(a));
		System.out.println("round:"+Math.round(c));
		System.out.println("ceil:"+Math.ceil(c));
		System.out.println("floor:"+Math.floor(c));
	}
	void logandangularmethod()
	{
		System.out.println("\n\n\t log and angular method");
		System.out.print("Degrees:"+Math.toDegrees(a));
		System.out.println("Radians:"+Math.toRadians(b));
		System.out.println("exponent:"+Math.exp(a));
		System.out.println("multiplication:"+Math.multiplyExact(b, a));
		System.out.println("Random:"+Math.random());
	}
	
}
public class func {
	public static void main(String arg[])
	{
	long a,b;
	double c;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the value for a:");
	a=sc.nextLong();
	System.out.println("enter the value for b:");
	b=sc.nextLong();
	System.out.println("enter the value for c:");
	c=sc.nextDouble();
	mathfunc mf=new mathfunc(a,b,c);
	mf.basicmathfunction();
	mf.logandangularmethod();
	}
	

}
