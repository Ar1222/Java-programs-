import java.util.Scanner;
public class palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		StringBuilder sb=new StringBuilder(str);
		sb.reverse();
		String rev=sb.toString();
		if(str.equals(rev))
		{
			System.out.println("Strings are palindrome");
		}
		else
		{
			System.out.println("Strings are not palindrome");
		}

	}

}
