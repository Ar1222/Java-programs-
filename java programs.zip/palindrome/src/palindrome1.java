import java.util.Scanner;
public class palindrome1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner sc=new Scanner(System.in);
  System.out.println("enter thenumber:");
	int n=sc.nextInt();
	int temp=n;
	int reverse = 0,rem;
	while(n!=0)
	{
		rem=n%10;
		reverse=(reverse*10)+rem;
		n=n/10;
	}
	if(temp==reverse)
	{
		System.out.println("palindrome");
	}
	else
	{
		System.out.println(" not palindrome");
	}
	}

}
