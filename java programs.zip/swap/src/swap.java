import java.util.Scanner;
public class swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner sc=new Scanner(System.in);
 System.out.println("before swapping");
		 System.out.println("enter the number 1:");
		 int a=sc.nextInt();
		 System.out.println("enter the number 2:");
		 int b=sc.nextInt();
		 System.out.println("after swapping");
		 int temp=a;
		 a=b;
		 b=temp;
		 System.out.println(a);
		 System.out.println(b);
		 
	}

}
