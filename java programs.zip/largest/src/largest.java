
public class largest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int a[]= {10,2,30,40,2,3};
  int max=a[0];
  int min=a[0];
  for(int i=0;i<a.length-1;i++)
  {
	  if(a[i]>max)
	  {
		  max=a[i];
	  }
	  else if(a[i]<min)
	  {
		  min=a[i];
	  }
  }
  System.out.println("maximum:"+max);
  System.out.println("minimum:"+min);
		  
  
	}

}
