import java.io.*;
import java.io.IOException;
public class copyfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\n\n\n\tCOPY THE FILE");
		try {
			FileInputStream f1=new FileInputStream("file1.txt");
			FileOutputStream f2=new FileOutputStream ("file2.txt");
			int c;
			while((c=f1.read())!=-1)
			{
				f2.write(c);
			}
				f1.close();
				f2.close();
				System.out.println("File copied succesfully");
		}
		catch(IOException e)
		{
			System.out.println("exception:"+e.toString());
		}

	}

}
