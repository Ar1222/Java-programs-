import java.util.Scanner;
public class lcm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner sc=new Scanner(System.in);
 System.out.println("enter the number:");
 int a=sc.nextInt();
 System.out.println("enterthe number 2:");
 int b=sc.nextInt();
 int t1=a,t2=b;
 while(a%b!=0)
 {
	 int temp=a%b;
	 a=b;
	 b=temp;
 }
 System.out.println("GCD:"+b);
 int lcm=(t1+t2)/b;
 System.out.println("LCM:"+lcm);
	}

}
