import java.applet.*;
import java.awt.*;
public class applet  extends  Applet{
	public void paint(Graphics g)
	{
		g.drawString("hello world",200,200);
	}
   //<applet code="applet.class" height="400" width="400"></applet>
}
