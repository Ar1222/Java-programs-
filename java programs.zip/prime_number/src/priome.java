import java.util.Scanner;
public class priome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("enter the number limit:");
int m=sc.nextInt();
int i,n;

start:
	for(n=2;n<m;n++)
	{
		for(i=2;i<n;i++)
			if(n%i==0)
				continue start;
		System.out.println(n);
	}

	

	}

}
