import java.util.Scanner;
public class evenodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the limit:");
		int n=sc.nextInt();
		int e=0,o=0;
		int a[]=new int[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("a["+i+"] value is:");
			a[i]=sc.nextInt();
		}
		for(int c:a)
		{
			if(c%2==0)
			{
				e++;
			}
			else
			{
				o++;
			}
		}
		System.out.println("even number :" +e);
		System.out.println("odd number :" +o);
	
		

	}

}
