import java.util.Scanner;

class chinnapilladivi extends Exception
{
	public chinnapilladivi(String s)
	{
		System.out.println(s);
	}
}
class userDefined 
{
	void getdata() throws chinnapilladivi
	{
		Scanner sc=new Scanner(System.in);
		int age=sc.nextInt();
		if(age<18)
		{
	     throw new chinnapilladivi("you are not eligible for voting");
		}
		else
		{
			System.out.println("you are eligible for voting");
		}
	}
}
public class exceptionhandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      userDefined obj =new userDefined();
      try {
      obj.getdata();
      }
      catch(Exception e)
      {
    	  System.out.println(e);
      }
      finally
      {
    	  System.out.println("Thanks you");
      }
		
	}

}
