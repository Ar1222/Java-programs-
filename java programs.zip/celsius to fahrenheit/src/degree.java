import java.util.Scanner;
public class degree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float f,c;
		Scanner sc=new Scanner(System.in);
		f=sc.nextFloat();
		c=(5/9)*(f-32);
		System.out.println("fahrenheit to celsius:"+c);
		c=sc.nextFloat();
		f=((c*9)/5)+32;
		System.out.println("celsius to fahrenheit:"+f);
		
		
		char s=sc.next().charAt(0);
		if(s=='a'||s=='e'||s=='i'||s=='o'||s=='u')
		{
		System.out.println("vowels");
		}
		else
		{
		System.out.println("consonants");
		}

	}

}
