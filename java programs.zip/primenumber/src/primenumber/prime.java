package primenumber;

public class prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,i=1,max=15;
		System.out.println("prime number between 1 to 15");
		System.out.println(i);
		start:
			for(n=2;n<max;n++)
			{
				for(i=2;i<n;i++)
					if(n%i==0)
						continue start;
						System.out.println(n);
						
			}
		
    }

}
