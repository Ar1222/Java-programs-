import java.util.Scanner;
public class lcmgecd {

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);

		System.out.println("enter the number1:");
		  int n1=sc.nextInt();
		  System.out.println("enter the number2:");
		  int n2=sc.nextInt();
		  int t1=n1,t2=n2;
		  if(n1%n2!=0)
		  {
			  int r=n1%n2;
			  n1=n2;
			  n2=r;
		  }
		  int lcm=(t1+t2)/n2;
		  System.out.println("lcm:"+lcm);
		 
		  System.out.println("gcd:"+n2);
		  
	}

}
