import java.util.Scanner;
public class digits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("enter the number:");
int n=sc.nextInt();
int num=0,digit,sum=0;
for(int i=0;i<n;i++)
{
  digit=n%10;
  sum=sum+digit;
  n=n/10;
}
System.out.println(sum);

	}

}
