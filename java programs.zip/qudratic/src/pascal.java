import java.util.Scanner;
public class pascal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
   System.out.println("enter the number:");
    int n=sc.nextInt();
    int space=n;
    int number=1;
    for(int i=0;i<n;i++)
    {
    	for(int s=0;s<=space;s++)
    	{
    		System.out.print(" ");
    	}
    	number=1;
    	for(int j=0;j<=i;j++)
    	{
    		System.out.print(number+" ");
    		number=number*(i-j)/(j+1);
    	}
    	space--;
    	System.out.println(" ");
    	
    }
	}

}
