import java.util.Scanner;
public class l {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter the number1:");
int n1=sc.nextInt();
System.out.println("Enter the number2:");
int n2=sc.nextInt();
int t1=n1,t2=n2;
while(n1%n2!=0)
{
	int r=n1%n2;
	n1=n2;
	n2=r;
}
System.out.println("gcd:"+n2);
int lcm=(t1+t2)/n2;
System.out.println("lcm:"+lcm);
}

	}


