import java.util.Scanner;
public class converstion1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner sc=new Scanner(System.in);
  System.out.println("enter the buinary number:");
  String binary=sc.nextLine();
  int dec=Integer.parseInt(binary, 2);
  System.out.println("decimal:"+dec);
  String octal=Integer.toOctalString(dec);
  System.out.println("ocatl:"+octal);
  

	}

}
