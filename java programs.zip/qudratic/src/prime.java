
public class prime {

	public static void main(String[] args) {
	
	int i,j;
  for( i=1;i<=115;i++)
  {
	  for( j=2;j<=i;j++)
	  {
		  if(i%j==0)
		  {
			  break;
		  }
	  }
	  if(i==j)
	  {
		 System.out.print(" "+i) ;
	  }
	  	 }
  System.out.println("\nHi\nHEllo\nbye");
   
	}

}
