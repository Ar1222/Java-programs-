 import java.lang.Math;
 import java.util.Scanner;
public class qudratic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		float a=sc.nextFloat();
		float b=sc.nextFloat();
		float c=sc.nextFloat();
		float d=b*b-4*a*c;
		if(d==0)
		{
			float root1,root2;
			System.out.println("roots are equal");    
			 root1=root2=(-b/2*a);
			 System.out.println("root1=root2="+root1);
		}
		else if(d>0)
		{
			float root1,root2;
			System.out.println("roots are real and unequal");
			 root1=(float) (-b+Math.sqrt(d))/2*a;
			 root2=(float)(-b-Math.sqrt(d))/2*a;
			 System.out.println("root1="+root1);
			 System.out.println("root2="+root2);	
		}
		else 
		{
			float root1,root2;
			System.out.println("roots are imaginary");
		float 	realp=-b/2*a;
		float imgp=(float) ((Math.sqrt(d))/2*a);
			 System.out.println("root1="+realp+"+i"+imgp);
			 System.out.println("root2="+realp+"-i"+imgp);
			
		}
		

	}

}
