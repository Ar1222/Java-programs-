import java.util.Scanner;
public class count {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("enter the number:");
int n=sc.nextInt();
int count=0,i;
while(n!=0)
{
	n=n/10;
count=count+1;
	
	
}
System.out.println(count);
	
	}

}
