
public class oddeven {
 public static void main(String arg[])
 {
	 int i=0,n=10;
	 
	 if((n&1)==i)
	 {
	  System.out.println("even number");
	 }
	 else
	 {
	 System.out.println("odd number");
	 }
	 }
 
	 }

