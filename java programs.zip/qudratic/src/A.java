import java.util.Scanner;
public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner sc=new Scanner(System.in);
  System.out.println("enter the number:");
  int a=sc.nextInt();
  System.out.println("enter the number:");
  int b=sc.nextInt();
  System.out.println("enter the number:");
  int c=sc.nextInt();
  double d=b*b-4*a*c;
  if(d==0)
  {
	  float root1,root2;
	  System.out.println("roots are equal");
	  root1=root2=-b/2*a;
	  System.out.println("root1 and root2="+root1);
  }
  else if(d>0)
  {
	  float root1,root2;
	  System.out.println("roots are unequal");
	  root1= (float)(-b+(Math.sqrt(d))/2*a);
	  root2=(float)(-b-(Math.sqrt(d))/2*a);
	  System.out.println("root1:"+root1);
	  System.out.println("root2:"+root2);
	  
	  
  }
  else
  {
	  float root1,root2;
	  System.out.println("roots are imaginary");
	  root1=-b/2*a;
	  root2=(float)(Math.sqrt(d))/2*a;
	  System.out.println("root1:"+root1);
	  System.out.println("root2:"+root1);
  }
  
	}

}
