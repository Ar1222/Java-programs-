import java.util.Scanner;
public class factor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner cs=new Scanner(System.in);
		System.out.println("enter thr number:");
		int n=cs.nextInt();
		for(int i=1;i<=n;i++)
		{
			if(n%i==0)
			{
				System.out.println(i);
			}
		}

	}

}
