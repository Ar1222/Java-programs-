import java.util.Scanner;
class convert
{
	int num;
	void convert1()
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number:");
	num=sc.nextInt();
	}
}
class convertion extends convert
{
	void convert1()
	{
		super.convert1();
		String hexa=Integer.toHexString(num);
		System.out.println(" hexadecimal of the number:"+hexa);
		String octal=Integer.toOctalString(num);
		System.out.println("octal of the number:"+octal);
		String binary=Integer.toBinaryString(num);
		System.out.println("binary of the number:"+binary);
	}
}

public class decimalconvertion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       convertion c=new convertion();
       c.convert1();
	}

}
