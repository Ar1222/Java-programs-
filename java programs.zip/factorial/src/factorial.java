import java.util.Scanner;
public class factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int i=5, n,fact=1;
   for(n=1;n<=i;n++)
   {
	  fact=fact*n; 
   }
   System.out.println("factorial of number is:"+fact);
	}

}
