import java.util.Arrays;
public class insertanelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int a[]= {10,20,30,40,50,60,70};
      int index=2;
      int value=38;
      System.out.println("before sorting:"+Arrays.toString(a));
      for(int i=a.length-1;i>index;i--)
      { 
    	  a[i]=a[i-1];
      }
      a[index]=value;
      System.out.println("after sorting:"+Arrays.toString(a));
	}

}
