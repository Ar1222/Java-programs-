import java.util.Scanner;
public class if_else {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m;
		System.out.println("enter the mark");
		Scanner sc=new Scanner(System.in);
		m=sc.nextInt();
		if(m>90&&m<=100)
		{
			System.out.println("grade A");
		}
		else if(m<=90&&m>80)
		{
			System.out.println("grade B");

		}
		else if(m<=80&&m>70)
		{
			System.out.println("grade C");
		}
		else if(m<60&&m>=40)
		{
			System.out.println("grade D");

		}

	}

}
