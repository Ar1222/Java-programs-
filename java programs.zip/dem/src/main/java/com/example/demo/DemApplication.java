package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemApplication.class, args);
		System.out.println("My dream to get an intership in Google");
		StringBuilder str=new StringBuilder("your dream will come true");
		System.out.println(str);
	}

}
