import java.util.Scanner;
public class converstion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("enter the binary number:");
String bin=sc.nextLine();
int decimal=Integer.parseInt(bin,2);
System.out.println("DEcimal number;"+decimal);
String octal=Integer.toOctalString(decimal);
System.out.println("ocatl number:"+octal);

	}

}

