import java.util.Scanner;
public class perfectnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner sc=new Scanner(System.in);
 System.out.println("enter the number:");
 int n=sc.nextInt();
 int sum=0;
 for(int i=0;i<=n;i++)
 {
	 if(i%n==0)
	 {
		 sum+=i;
	 }
 }
 if(sum==n)
 {
	 System.out.println(n+" is perfect number ");
 }
 else
 {
	 System.out.println(n+" is not perfect number ");
 }
	}

}
