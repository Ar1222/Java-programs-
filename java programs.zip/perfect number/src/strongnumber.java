import java.util.Scanner;
public class strongnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("enter the number:");
int n=sc.nextInt();
int temp=n,fact,rem ,sum=0;
while(n>0)
{
	rem=n%10;
	System.out.println(rem+"remainder");
 fact=1;
for(int i=1;i<=rem;i++)
	{
		fact=fact*i;
	
	}
	System.out.println(fact+" : factorial number");
	sum+=fact;
	n=n/10;
	
}
if(sum==temp)
{
	System.out.println("strong number");
	
}
else
{
	System.out.println(" not a strong number");
}



	}

}
